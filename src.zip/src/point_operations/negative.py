import cv2


def negative_image(input_path, output_path):
    """
    Biến đổi ảnh thành ảnh âm bản.

    Công thức:
        s = 255 - r

    Parameters:
        input_path: đường dẫn ảnh đầu vào
        output_path: đường dẫn lưu ảnh kết quả
    """

    # Đọc ảnh
    image = cv2.imread(input_path)

    if image is None:
        raise ValueError(
            f"Không thể đọc ảnh đầu vào: {input_path}"
        )

    # Tạo ảnh âm bản
    negative = 255 - image

    # Lưu ảnh kết quả
    success = cv2.imwrite(output_path, negative)

    if not success:
        raise ValueError(
            f"Không thể lưu ảnh kết quả: {output_path}"
        )

    print(f"Negative: {output_path}")

    return negative