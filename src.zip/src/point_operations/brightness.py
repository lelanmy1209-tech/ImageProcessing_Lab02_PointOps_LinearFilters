import cv2


def change_brightness(input_path, output_path, beta=0):
    """
    Thay đổi độ sáng của ảnh.

    beta > 0: tăng độ sáng
    beta < 0: giảm độ sáng
    """

    image = cv2.imread(input_path)

    if image is None:
        raise ValueError(f"Không thể đọc ảnh: {input_path}")

    result = cv2.convertScaleAbs(
        image,
        alpha=1.0,
        beta=beta
    )

    cv2.imwrite(output_path, result)

    return result