import cv2


def change_contrast(input_path, output_path, alpha=1.0):
    """
    Thay đổi độ tương phản của ảnh.

    alpha > 1: tăng độ tương phản
    0 < alpha < 1: giảm độ tương phản
    alpha = 1: giữ nguyên
    """

    # Đọc ảnh
    image = cv2.imread(input_path)

    if image is None:
        raise ValueError(f"Không thể đọc ảnh: {input_path}")

    # Thay đổi độ tương phản
    result = cv2.convertScaleAbs(image, alpha=alpha, beta=0)

    # Lưu ảnh
    cv2.imwrite(output_path, result)

    return result