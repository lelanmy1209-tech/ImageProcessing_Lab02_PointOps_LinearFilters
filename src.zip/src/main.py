import os

from point_operations.brightness import change_brightness
from point_operations.contrast import change_contrast
from point_operations.negative import negative_image
from point_operations.threshold import threshold_image

from linear_filters.mean_filter import mean_filter
from linear_filters.gaussian_filter import gaussian_filter
from linear_filters.sharpening import sharpen_image


def main():

    print("=" * 60)
    print("IMAGE PROCESSING LAB 02")
    print("POINT OPERATIONS & LINEAR FILTERS")
    print("=" * 60)

    # =========================================================
    # 1. Đường dẫn
    # =========================================================

    input_path = os.path.join(
        "data",
        "input",
        "input.jpg"
    )

    output_point = os.path.join(
        "data",
        "output",
        "point_operations"
    )

    output_linear = os.path.join(
        "data",
        "output",
        "linear_filters"
    )

    # Tạo thư mục output nếu chưa tồn tại
    os.makedirs(output_point, exist_ok=True)
    os.makedirs(output_linear, exist_ok=True)

    # =========================================================
    # 2. Kiểm tra ảnh đầu vào
    # =========================================================

    if not os.path.exists(input_path):
        print()
        print("❌ KHÔNG TÌM THẤY ẢNH ĐẦU VÀO!")
        print()
        print(f"Đường dẫn cần có:")
        print(os.path.abspath(input_path))
        print()
        print("Hãy kiểm tra:")
        print("data/input/input.jpg")
        return

    print()
    print(f"Ảnh đầu vào: {input_path}")
    print()

    # =========================================================
    # 3. POINT OPERATIONS
    # =========================================================

    print("-" * 60)
    print("POINT OPERATIONS")
    print("-" * 60)

    # ---------------------------------------------------------
    # 3.1 Brightness
    # ---------------------------------------------------------

    print("[1/7] Đang xử lý Brightness...")

    brightness_output = os.path.join(
        output_point,
        "brightness.jpg"
    )

    change_brightness(
        input_path,
        brightness_output,
        beta=50
    )

    print("      ✓ Brightness hoàn tất")

    # ---------------------------------------------------------
    # 3.2 Contrast
    # ---------------------------------------------------------

    print("[2/7] Đang xử lý Contrast...")

    contrast_output = os.path.join(
        output_point,
        "contrast.jpg"
    )

    change_contrast(
        input_path,
        contrast_output,
        alpha=1.5
    )

    print("      ✓ Contrast hoàn tất")

    # ---------------------------------------------------------
    # 3.3 Negative
    # ---------------------------------------------------------

    print("[3/7] Đang xử lý Negative...")

    negative_output = os.path.join(
        output_point,
        "negative.jpg"
    )

    negative_image(
        input_path,
        negative_output
    )

    print("      ✓ Negative hoàn tất")

    # ---------------------------------------------------------
    # 3.4 Threshold
    # ---------------------------------------------------------

    print("[4/7] Đang xử lý Threshold...")

    threshold_output = os.path.join(
        output_point,
        "threshold.jpg"
    )

    threshold_image(
        input_path,
        threshold_output,
        threshold=128
    )

    print("      ✓ Threshold hoàn tất")

    # =========================================================
    # 4. LINEAR FILTERS
    # =========================================================

    print()
    print("-" * 60)
    print("LINEAR FILTERS")
    print("-" * 60)

    # ---------------------------------------------------------
    # 4.1 Mean Filter
    # ---------------------------------------------------------

    print("[5/7] Đang xử lý Mean Filter...")

    mean_output = os.path.join(
        output_linear,
        "mean.jpg"
    )

    mean_filter(
        input_path,
        mean_output,
        kernel_size=3
    )

    print("      ✓ Mean Filter hoàn tất")

    # ---------------------------------------------------------
    # 4.2 Gaussian Filter
    # ---------------------------------------------------------

    print("[6/7] Đang xử lý Gaussian Filter...")

    gaussian_output = os.path.join(
        output_linear,
        "gaussian.jpg"
    )

    gaussian_filter(
        input_path,
        gaussian_output,
        kernel_size=5,
        sigma=1.0
    )

    print("      ✓ Gaussian Filter hoàn tất")

    # ---------------------------------------------------------
    # 4.3 Sharpening
    # ---------------------------------------------------------

    print("[7/7] Đang xử lý Sharpening...")

    sharpening_output = os.path.join(
        output_linear,
        "sharpening.jpg"
    )

    sharpen_image(
        input_path,
        sharpening_output
    )

    print("      ✓ Sharpening hoàn tất")

    # =========================================================
    # 5. KẾT QUẢ
    # =========================================================

    print()
    print("=" * 60)
    print("HOÀN THÀNH!")
    print("=" * 60)

    print()
    print("Point Operations:")
    print(os.path.abspath(output_point))

    print()
    print("Linear Filters:")
    print(os.path.abspath(output_linear))

    print()
    print("Các file kết quả:")
    print("  - brightness.jpg")
    print("  - contrast.jpg")
    print("  - negative.jpg")
    print("  - threshold.jpg")
    print("  - mean.jpg")
    print("  - gaussian.jpg")
    print("  - sharpening.jpg")

    print()
    print("=" * 60)


if __name__ == "__main__":
    main()